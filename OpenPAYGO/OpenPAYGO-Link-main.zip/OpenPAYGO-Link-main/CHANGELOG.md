# Changelog

## 2020-12-14: v1.0 Release Candidate 0
- Added support for slave-initiated communication
- Added Eagle files for the hardware examples
- Improved examples code quality
- Improved documentation

## 2020-11-23: v1.0 Beta
- First version published on the repository
- Fully functional with examples provided
- Does not yet support slave-initiated communication