# OpenPAYGO Metrics

This repository contains all the information you need to integrate OpenPAYGO Metrics into your device or PAYGO software. 

To get started, check out [that document](https://github.com/openpaygo/metrics/blob/main/OpenPAYGO%20Metrics%20-%20API%20Specifications.pdf).

**Warning:** This specifications is still at an early stage and might evolve based on feedback over the next few months though care will be taken to keep it as retrocompatible as possible. 

## Changelog

### 2021-05-10 - v0.12
- First version published on Github
- Clarified the headers needed for JSON and CBOR content
