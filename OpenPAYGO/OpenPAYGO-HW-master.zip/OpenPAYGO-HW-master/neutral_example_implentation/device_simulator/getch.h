#ifndef getch_h
#define getch_h

#include <stdio.h>

int getch(void);

#endif
