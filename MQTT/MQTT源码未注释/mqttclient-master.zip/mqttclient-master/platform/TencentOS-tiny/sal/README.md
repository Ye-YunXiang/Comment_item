# 注意

如果用的是AT模组，可以结合TencentOS tiny的AT框架与SAL层使用platform_net_socket.c，替换原有BSD socket 接口即可。